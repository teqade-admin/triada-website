import { useState, useEffect, useRef } from 'react';
import { MapPin, ChevronLeft, ChevronRight, Target, Users, MessageSquare, Palette, BarChart3, Brain, Lightbulb, TrendingUp, Map, Zap, Rocket, Award } from 'lucide-react';
import './Navbar.css';
import AnimatedTriada from './AnimatedTriada';

// Navbar Component
const Navbar = () => {
  return (
    <nav className="navbar">
      <div className="navbar-container">
        <div className="navbar-logo brand-heading">
          <AnimatedTriada className="triada-animation" size="normal" />
        </div>
        <ul className="navbar-menu brand-body">
          <li><a href="#home">Home</a></li>
          <li><a href="#services">Services</a></li>
          <li><a href="#process">Process</a></li>
          <li><a href="#about">About</a></li>
          <li><a href="#contact">Contact</a></li>
        </ul>
      </div>
    </nav>
  );
};

export default Navbar;